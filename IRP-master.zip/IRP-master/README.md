# IRP
Incident Response Playbooks

https://www.peerlyst.com/posts/incident-response-playbooks-wiki-j-geno-j-geno

https://www.demisto.com/resources/

https://www.incidentresponse.com/playbooks/

https://www.peerlyst.com/posts/guidance-for-incident-response-play-books?trk=tag_page_posts_panel_activity_feed
