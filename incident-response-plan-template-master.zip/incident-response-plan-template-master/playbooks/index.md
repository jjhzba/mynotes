# Playbooks

The following playbooks capture common [investigation](#investigate), [remediation](#remediate), and [communication](#communicate) steps for particular types of incident.

`TODO: Create additional playbooks for highly likely or highly damaging incident types.`

